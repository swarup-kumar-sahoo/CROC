# 🐊 croc

> A Python library for building server-driven single-page applications.

croc lets you build interactive web UIs entirely in Python — no JavaScript, no HTML templates. It uses **FastAPI** + **WebSockets** under the hood, with a thin JS client in the browser that renders a component tree sent from your Python server.

---

## Installation

```bash
pip install croc
```

Or install from source:

```bash
git clone https://github.com/yourname/croc
cd croc
pip install -e .
```

---

## Quick Start

```python
import croc

app = croc.App(title="My App")
state = croc.State(count=0)

@app.page("/")
def home():
    def increment():
        state.count += 1

    return croc.Page([
        croc.Heading("Counter"),
        croc.Text(f"Count: {state.count}"),
        croc.Button("Click me!", on_click=increment),
    ])

app.run()
```

Open `http://localhost:8000` — that's it.

---

## How It Works

```
┌─────────────────────────────────────┐
│  Python (your app)                  │
│  ┌─────────┐   ┌─────────────────┐  │
│  │  State  │──▶│  Component Tree │  │
│  └─────────┘   └────────┬────────┘  │
│                         │ JSON      │
│              FastAPI + WebSocket    │
└─────────────────────────┼───────────┘
                          │
┌─────────────────────────▼───────────┐
│  Browser (croc-client.js)           │
│  Renders tree → DOM                 │
│  Events (click/change) → WebSocket  │
└─────────────────────────────────────┘
```

1. You define pages with Python components
2. croc serializes the component tree to JSON
3. The browser renders the JSON tree to real DOM using Tailwind CSS
4. User interactions (clicks, inputs) are sent back over WebSocket
5. Python handles the event → state updates → re-render is pushed to browser

---

## Components

### Layout
| Component | Description |
|-----------|-------------|
| `Page` | Top-level page wrapper |
| `VStack` | Vertical flex column |
| `HStack` | Horizontal flex row |
| `Grid` | CSS Grid layout |
| `Box` | Generic container |
| `Center` | Centers its children |
| `Divider` | Horizontal rule |
| `Spacer` | Flexible spacing |

### Text
| Component | Description |
|-----------|-------------|
| `Heading` | h1–h6 headings |
| `Text` | Paragraph text |
| `Label` | Form labels |
| `Badge` | Status badges |
| `Code` | Inline or block code |
| `Link` | Hyperlinks (SPA-aware) |

### Input
| Component | Description |
|-----------|-------------|
| `Button` | Clickable button |
| `Input` | Text input |
| `Textarea` | Multi-line input |
| `Select` | Dropdown select |
| `Checkbox` | Checkbox |
| `Switch` | Toggle switch |
| `Slider` | Range slider |

### Display
| Component | Description |
|-----------|-------------|
| `Card` | Content card |
| `Alert` | Alert banner |
| `Table` | Data table |
| `Image` | Image display |
| `Progress` | Progress bar |
| `Spinner` | Loading spinner |
| `Avatar` | User avatar |
| `Stat` | Metric/stat display |

---

## State Management

```python
state = croc.State(name="Alice", count=0, dark=False)

# Reading state
print(state.count)  # 0

# Writing state (triggers re-render automatically)
state.count += 1

# Batch update
state.update(name="Bob", count=10)
```

---

## Routing

```python
@app.page("/")
def home():
    return croc.Page([croc.Heading("Home")])

@app.page("/about")
def about():
    return croc.Page([croc.Heading("About")])

@app.not_found
def not_found():
    return croc.Page([croc.Heading("404 — Not Found")])
```

Client-side navigation (no page reload):

```python
croc.Link("About", href="/about")
```

---

## Running the Demo

```bash
python examples/demo.py
```

Then visit `http://localhost:8000`.

---

## Roadmap

- **v0.1** — Server-driven UI, WebSocket core, 24 components, routing, state ✅
- **v0.2** — Reactive state subscriptions, component lifecycle hooks
- **v0.3** — Static HTML export
- **v1.0** — Hybrid mode (server + static), themes, custom component support

---

## License

MIT
